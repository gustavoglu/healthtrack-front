

let registerButton = document.getElementById('registerButton');
let loginButton = document.getElementById('loginButton');
registerButton.addEventListener('click', () => {

    document.location.href = "views/register.html";
})
loginButton.addEventListener('click', () => {

    document.location.href = "views/dashboard.html";
})